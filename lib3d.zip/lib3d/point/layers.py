import tensorflow as tf
import tensorflow_addons as tfa
import os, sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(os.path.dirname(BASE_DIR))

#=============================import the point convolution modules============================
sys.path.append(os.path.join(ROOT_DIR, 'tf_ops/point/convolution'))
sys.path.append(os.path.join(ROOT_DIR, 'tf_ops/point/pooling'))
sys.path.append(os.path.join(ROOT_DIR, 'tf_ops/point/unpooling'))
import tf_conv3d, tf_pool3d, tf_unpool3d
#======================================End of importing=========================================


def _filter_variable_(name, shape, stddev, use_xavier=True):
    """Helper to create an initialized Variable with weight decay.

    Note that the Variable is initialized with a truncated normal distribution.
    A weight decay is added only if one is specified.

    Args:
        name: name of the variable
        shape: list of ints
        stddev: standard deviation of a truncated Gaussian
        use_xavier: bool, whether to use the Xavier(Glorot) normal initializer
    Returns:
        Variable Tensor
    """
    if use_xavier:
        initializer = tf.keras.initializers.GlorotNormal()
    else:
        initializer = tf.keras.initializers.TruncatedNormal(stddev=stddev)
    # variable is trainable in default.
    var = tf.Variable(initial_value=initializer(shape=shape),
                      trainable=True, name=name, dtype=tf.float32)
    return var


class batch_normalization(tf.Module):
    def __init__(self, scope=''):
        super(batch_normalization,self).__init__()
        self.norm_fn = tf.keras.layers.BatchNormalization(axis=-1, momentum=0.99,
                                    beta_regularizer=tf.keras.regularizers.l2(1.0),
                                    gamma_regularizer=tf.keras.regularizers.l2(1.0),
                                    name=scope+'/BN')

    def __call__(self, data, is_training):
        return self.norm_fn(data, training=is_training)


class dropout(tf.Module):

    def __init__(self, drop_rate=0.5):
        super(dropout,self).__init__()
        self.DP = tf.keras.layers.Dropout(rate=drop_rate)

    def __call__(self, inputs, is_training):
        return self.DP(inputs, training=is_training)


class separable_conv3d(tf.Module):
    """ 3D separable convolution with non-linear operation.
    Args:
        inputs: 3-D tensor variable BxNxC
        num_out_channels: int
        kernel_size: int
        depth_multiplier: int
        nn_index: int32 array, neighbor indices
        nn_count: int32 array, number of neighbors
        filt_index: int32 array, filter bin indices
        filt_coeff: float32 array, filter bin component coefficients
        use_xavier: bool, use xavier_initializer if true
        stddev: float, stddev for truncated_normal init
        activation_fn: function
        with_bn: bool, whether to use batch norm
        with_bias: bool, whether to use bias
        is_training: bool Tensor variable
    Returns:
      Variable tensor
    """
    def __init__(self, in_channels, out_channels, kernel_size, depth_multiplier=1,
                 scope='', use_xavier=True, stddev=1e-3,  with_bn=True,
                with_bias=False, activation_fn=tf.nn.elu):
        super(separable_conv3d, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.scope = scope
        self.kernel_size = kernel_size
        self.multiplier = depth_multiplier
        self.use_xavier = use_xavier
        self.stddev = stddev
        self.with_bn = with_bn
        self.with_bias = with_bias
        self.activation_fn = activation_fn
        self.filter = {}
        self.BatchNorm = batch_normalization(scope=self.scope)

    def build_kernel(self):
        # depthwise kernel shape
        depthwise_kernel_shape = [self.kernel_size, self.in_channels, self.multiplier]
        self.filter['depthwise'] = _filter_variable_(self.scope+'/depthwise_weights',
                                       shape=depthwise_kernel_shape, stddev=self.stddev,
                                       use_xavier=self.use_xavier)
        # pointwise kernel shape
        kernel_shape = [self.in_channels*self.multiplier, self.out_channels]
        self.filter['pointwise'] = _filter_variable_(self.scope+'/pointwise_weights',
                                       shape=kernel_shape, use_xavier=self.use_xavier,
                                       stddev=self.stddev)
        # biases term
        if self.with_bias:
            self.filter['biases'] = tf.Variable(tf.zeros(self.out_channels, dtype=tf.float32),
                                                name=self.scope+'/biases')

    def __call__(self, inputs, nn_index, nn_count, filt_index, filt_coeff=None,
                 is_training=None):
        if not self.filter:
            self.build_kernel()

        if filt_coeff is None:
            outputs = tf_conv3d.depthwise_conv3d(inputs, self.filter['depthwise'], nn_index,
                                                 nn_count, filt_index)
        else:
            outputs = tf_conv3d.fuzzy_depthwise_conv3d(inputs, self.filter['depthwise'], nn_index,
                                                       nn_count, filt_index, filt_coeff)

        # pointwise convolution with tf.matmul,
        # it takes less memory, and is also more efficient
        batch_size = inputs.shape[0]
        outputs = tf.reshape(outputs, [-1, self.in_channels*self.multiplier])
        outputs = tf.matmul(outputs, self.filter['pointwise'])
        outputs = tf.reshape(outputs, [batch_size, -1, self.out_channels])
        if self.with_bias:
            outputs = tf.nn.bias_add(outputs, self.filter['biases'])
        if self.activation_fn is not None:
            outputs = self.activation_fn(outputs)
        if self.with_bn:
            outputs = self.BatchNorm(outputs, is_training)

        return outputs


class pointwise_conv3d(tf.Module):
    """ pointwise convolution with non-linear operation.
    Args:
        inputs: 3-D tensor variable BxNxC
        num_out_channels: int
        use_xavier: bool, use xavier_initializer if true
        stddev: float, stddev for truncated_normal init
        activation_fn: function
        with_bn: bool, whether to use batch norm
        with_bias: bool, whether to use bias
        is_training: bool Tensor variable
    Returns:
        Variable tensor
    """
    def __init__(self, in_channels, out_channels, scope='', use_xavier=True,
                 stddev=1e-3, with_bias=False, with_bn=True, activation_fn=tf.nn.elu):
        super(pointwise_conv3d, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.scope = scope
        self.use_xavier = use_xavier
        self.stddev = stddev
        self.with_bn = with_bn
        self.with_bias = with_bias
        self.activation_fn = activation_fn
        self.filter = {}
        self.BatchNorm = batch_normalization(scope=self.scope)

    def build_kernel(self):
        # pointwise kernel shape
        kernel_shape = [self.in_channels, self.out_channels]
        self.filter['pointwise'] = _filter_variable_(self.scope+'/pointwise_weights',
                                       shape=kernel_shape, use_xavier=self.use_xavier,
                                       stddev=self.stddev)
        # biases term
        if self.with_bias:
            self.filter['biases'] = tf.Variable(tf.zeros(self.out_channels,dtype=tf.float32),
                                                name=self.scope+'/biases')

    def __call__(self, inputs, is_training=None):
        if not self.filter:
            self.build_kernel()

        batch_size = inputs.shape[0]
        inputs = tf.reshape(inputs, [-1, self.in_channels])
        outputs = tf.matmul(inputs, self.filter['pointwise'])
        outputs = tf.reshape(outputs, [batch_size, -1, self.out_channels])
        if self.with_bias:
            outputs = tf.nn.bias_add(outputs, self.filter['biases'])
        if self.activation_fn is not None:
            outputs = self.activation_fn(outputs)
        if self.with_bn:
            outputs = self.BatchNorm(outputs, is_training)

        return outputs


class fully_connected(tf.Module):
    """ Fully connected layer with non-linear operation.
    Args:
        inputs: 2-D tensor variable BxC
        num_out_channels: int
        use_xavier: bool, use xavier_initializer if true
        stddev: float, stddev for truncated_normal init
        activation_fn: function
        with_bn: bool, whether to use batch norm
        with_bias: bool, whether to use bias
        is_training: bool Tensor variable
    Returns:
      Variable tensor of size B x num_out_channels
    """
    def __init__(self, in_channels, out_channels, scope='', use_xavier=True,
                 stddev=1e-3, activation_fn=tf.nn.elu, with_bn=True, with_bias=False):
        super(fully_connected, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.scope = scope
        self.use_xavier = use_xavier
        self.stddev = stddev
        self.with_bn = with_bn
        self.with_bias = with_bias
        self.activation_fn = activation_fn
        self.filter = {}
        self.BatchNorm = batch_normalization(scope=self.scope)

    def build_kernel(self):
        # fully-connected kernel shape
        kernel_shape = [self.in_channels, self.out_channels]
        self.filter['weights'] = _filter_variable_(self.scope+'/weights',
                                   shape=kernel_shape, use_xavier=self.use_xavier,
                                   stddev=self.stddev)
        # biases term
        if self.with_bias:
            self.filter['biases'] = tf.Variable(tf.zeros(self.out_channels,dtype=tf.float32),
                                                name=self.scope+'/biases')

    def __call__(self, inputs, is_training=None):
        if not self.filter: # define filter if self.filter is empty
            self.build_kernel()

        outputs = tf.matmul(inputs, self.filter['weights'])
        if self.with_bias:
            outputs = tf.nn.bias_add(outputs, self.filter['biases'])
        if self.activation_fn is not None:
            outputs = self.activation_fn(outputs)
        if self.with_bn:
            outputs = self.BatchNorm(outputs, is_training)
        return outputs


class pool3d(tf.Module):
    """ 3D pooling.
    Args:
        inputs: 3-D tensor BxNxC
        nn_index: int32 array, neighbor and filter bin indices
        nn_count: int32 array, number of neighbors
        method: string, the pooling method
    Returns:
        Variable tensor
    """
    def __init__(self, method='max'):
        super(pool3d, self).__init__()
        self.method = method

    def __call__(self, inputs, nn_index, nn_count):
        if self.method == 'max':
            outputs, max_index = tf_pool3d.max_pool3d(inputs, nn_index, nn_count)
        elif self.method == 'avg':
            outputs = tf_pool3d.avg_pool3d(inputs, nn_index, nn_count)
        else:
            raise ValueError("Unknow pooling method %s."%self.method)

        return outputs


class unpool3d(tf.Module):
    """ 3D unpooling
    Args:
        inputs: 3-D tensor BxNxC
        nn_index: int32 array, neighbor indices
        nn_count: int32 array, number of neighbors
        method: string, the unpooling method
        weight: float32 array, unpooling weights
    Returns:
        Variable tensor
    """
    def __init__(self, method):
        super(unpool3d, self).__init__()
        self.method = method

    def __call__(self, inputs, nn_index, nn_count, method, weight=None):
        if self.method == 'mean':
            outputs = tf_unpool3d.mean_interpolate(inputs, nn_index, nn_count)
        elif self.method == 'weighted':
            outputs = tf_unpool3d.weighted_interpolate(inputs, weight,
                                                       nn_index, nn_count)
        else:
            raise ValueError("Unknow unpooling method %s."%self.method)

        return outputs


if __name__=='__main__':
    DP = dropout(0.5)
    BN = batch_normalization(scope='bn')

    from termcolor import colored

    inputs = tf.random.uniform((6, 3))
    x = DP(inputs, is_training=True)
    print(colored('{}'.format(DP.trainable_variables),'green'))

    y = BN(inputs, is_training=True)
    print(colored('{}'.format(BN.trainable_variables),'magenta'))

    with tf.GradientTape(persistent=True) as tape:
        x1 = DP(inputs, is_training=True)
        print(colored('{}'.format(DP.trainable_variables),'cyan'))

        y1 = BN(inputs, is_training=True)
        print(colored('{}'.format(BN.trainable_variables),'red'))