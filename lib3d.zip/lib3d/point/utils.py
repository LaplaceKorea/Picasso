import tensorflow as tf
import tensorflow_addons as tfa
import os, sys
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(os.path.dirname(BASE_DIR))

#=============================import the point convolution modules============================
sys.path.append(os.path.join(ROOT_DIR, 'tf_ops/point/buildkernel'))
sys.path.append(os.path.join(ROOT_DIR, 'tf_ops/point/nnquery'))
sys.path.append(os.path.join(ROOT_DIR, 'tf_ops/point/sampling'))
sys.path.append(os.path.join(ROOT_DIR, 'tf_ops/point/weight_helper'))
from tf_nnquery import build_sphere_neighbor, build_cube_neighbor, build_nearest_neighbor
from tf_sample import farthest_point_sample, inverse_density_sample, random_sample
from tf_buildkernel import spherical_kernel, fuzzy_spherical_kernel
from weight_helper import ptcloud_dist2weight
#======================================End of importing=========================================

class Util:

    def __init__(self, sample_method='FPS', upsample_neighbor='sphere'):
        self.sample_method = sample_method
        self.upsample_neighbor = upsample_neighbor

    @staticmethod
    def search_nn3(xyz, xyz_query):
        nn_idx, nn_cnt, nn_dst = build_nearest_neighbor(xyz, xyz_query)
        return nn_idx, nn_cnt, nn_dst

    @staticmethod
    def search_range_neighbor(xyz, xyz_query, radius, max_nn):
        nn_idx, nn_cnt, nn_dst = build_sphere_neighbor(xyz, xyz_query,
                                       radius=radius, nnsample=max_nn)
        return nn_idx, nn_cnt, nn_dst

    def build_graph_sample(self, xyz, num_sample):
        # tf.assert(num_sample>0,'num_sample must be a positive integer!')
        # tf.assert(num_sample<tf.shape(xyz)[1],'num_sample must be less than the existing point number!')
        if self.sample_method=='random':
            sample_index = random_sample(num_sample, xyz)
        elif self.sample_method=='FPS':
            sample_index = farthest_point_sample(num_sample, xyz)
        else:
            raise ValueError('Unknown sampling method.')

        batch_size = tf.shape(xyz)[0]
        batch_indices = tf.tile(tf.reshape(tf.range(batch_size), (-1, 1, 1)), (1, num_sample, 1))
        indices = tf.concat([batch_indices, tf.expand_dims(sample_index, axis=2)], axis=2)
        return indices

    def build_graph_upsample(self, xyz_lowRes, xyz_highRes, radius=None, nn_uplimit=None):
        if self.upsample_neighbor=='sphere':
            inter_idx, inter_cnt, inter_dst = build_sphere_neighbor(xyz_lowRes, xyz_highRes,
                                                                    radius=radius,
                                                                    nnsample=nn_uplimit)
        elif self.upsample_neighbor=='nearest':
            inter_idx, inter_cnt, inter_dst = build_nearest_neighbor(xyz_lowRes, xyz_highRes)
        else:
            raise ValueError('Unknown neighbor search method.')

        return inter_idx, inter_cnt, inter_dst

    @staticmethod
    def get_upsample_weight(nn_count, nn_dist, wgt_type='inv_dist', radius=None):
        # default inverse distance based weights
        weight = ptcloud_dist2weight(nn_count, nn_dist, radius, type=wgt_type)
        return weight



class sph3dUtil(Util):

    def __init__(self, kernel_shape=np.asarray([8,4,1]), sample_method='FPS',
                       upsample_neighbor='nearest'):
        super(sph3dUtil,self).__init__(sample_method=sample_method,
                         upsample_neighbor=upsample_neighbor)
        self.kernel_shape = kernel_shape
        self.kernel_size = np.prod(kernel_shape)+1

    def build_graph_conv(self, xyz, xyz_query, radius, nn_uplimit):
        nn_idx, nn_cnt, nn_dst = build_sphere_neighbor(xyz, xyz_query, radius=radius,
                                                       nnsample=nn_uplimit)
        filt_idx = self._build_kernel(xyz, xyz_query, nn_idx, nn_cnt, nn_dst,
                                      radius)
        filt_coeff = None
        return nn_idx, nn_cnt, nn_dst, filt_idx, filt_coeff

    def _build_kernel(self, xyz, xyz_query, nn_idx, nn_cnt, nn_dst, radius):
        filt_idx = spherical_kernel(xyz, xyz_query, nn_idx, nn_cnt, nn_dst,
                                    radius, kernel=self.kernel_shape)
        return filt_idx


class fuzzysph3dUtil(Util):

    def __init__(self, kernel_shape=np.asarray([8,4,1]), sample_method='FPS',
                       upsample_neighbor='nearest'):
        super(fuzzysph3dUtil,self).__init__(sample_method=sample_method,
                         upsample_neighbor=upsample_neighbor)
        self.kernel_shape = kernel_shape
        self.kernel_size = np.prod(kernel_shape)+1

    def build_graph_conv(self, xyz, xyz_query, radius, nn_uplimit):
        nn_idx, nn_cnt, nn_dst = build_sphere_neighbor(xyz, xyz_query, radius=radius,
                                                       nnsample=nn_uplimit)
        filt_idx, filt_coeff = self._build_kernel(xyz, xyz_query, nn_idx,
                                                  nn_cnt, nn_dst, radius)
        return nn_idx, nn_cnt, nn_dst, filt_idx, filt_coeff

    def _build_kernel(self, xyz, xyz_query, nn_idx, nn_cnt, nn_dst, radius):
        filt_idx, filt_coeff = fuzzy_spherical_kernel(xyz, xyz_query, nn_idx,
                                                      nn_cnt, nn_dst, radius,
                                                      kernel=self.kernel_shape)
        return filt_idx, filt_coeff


class cnn3dUtil(Util):

    def __init__(self, grid_size=4, sample_method='FPS', upsample_neighbor='nearest'):
        super(cnn3dUtil,self).__init__(sample_method=sample_method,
                               upsample_neighbor=upsample_neighbor)
        self.grid_size = grid_size
        self.kernel_size = grid_size**3

    def build_graph_conv(self, xyz, xyz_query, radius, nn_uplimit):
        nn_idx, nn_cnt = build_cube_neighbor(xyz, xyz_query, length=2*radius,
                                             nnsample=nn_uplimit,
                                             gridsize=self.grid_size)
        nn_idx, filt_idx = self._build_kernel(nn_idx)
        nn_dst, filt_coeff = None, None
        return nn_idx, nn_cnt, nn_dst, filt_idx, filt_coeff

    # The input intra_idx is the first value returned by build_cube_neighbor
    @staticmethod
    def _build_kernel(intra_idx):
        filt_idx = intra_idx[...,1]
        intra_idx = intra_idx[...,0]
        return intra_idx, filt_idx
