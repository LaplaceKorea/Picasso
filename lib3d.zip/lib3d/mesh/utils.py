import tensorflow as tf
import os, sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(os.path.dirname(BASE_DIR))

#==============================import the mesh convolution modules==============================
sys.path.append(os.path.join(ROOT_DIR, 'tf_ops/mesh/decimation'))
sys.path.append(os.path.join(ROOT_DIR, 'tf_ops/mesh/weight_helper'))
from tf_decimate import mesh_decimation, compute_triangle_geometry
from tf_decimate import count_vertex_adjface, compute_vertex_geometry
from tf_decimate import combine_clusters
from mesh_weight_helper import mesh_metric2weight
#======================================End of importing=========================================


class meshUtil:

    def __init__(self, kernel_type='gmmComponents', useArea=True, wgtBnd=10,
                       shuffleBins=500):
        self.kernel_type = kernel_type
        # self.sample_method = 'mesh_decimation'
        # self.upsample_neighbor = 'vertexClusters'
        self.useArea = useArea
        self.wgtBnd = wgtBnd
        self.shuffleBins = shuffleBins
        self.wgtConsist = 0 # currently, we don't handle consistency during the decimation

    # def simplify_mesh(self, vertexIn, faceIn, geometryIn, nvIn, mfIn, nvSample):
    #     vertexOut, faceOut, geometryOut, nvOut, mfOut,  \
    #     repOut, mapOut = mesh_decimation(vertexIn, faceIn, geometryIn, nvIn, mfIn,
    #                                      nvSample, useArea=self.useArea,
    #                                      shuffleBins=self.shuffleBins,
    #                                      wgtBnd=self.wgtBnd, wgtConsist=self.wgtConsist)
    #     return vertexOut, faceOut, geometryOut, nvOut, mfOut, repOut, mapOut
    def simplify_mesh(self, vertexIn, faceIn, geometryIn, nvIn, mfIn, nvSample):
        vertexOut, faceOut, geometryOut, nvOut, mfOut,  \
        repOut, mapOut = mesh_decimation(vertexIn, faceIn, geometryIn, nvIn, mfIn,
                                         nvSample)
        return vertexOut, faceOut, geometryOut, nvOut, mfOut, repOut, mapOut


    # triangle geometry include [unit length normals, intercept of the triangle plane, face area]
    @staticmethod
    def get_triangle_geometry(vertex, face):
        geometry = compute_triangle_geometry(vertex[:,:3], face)
        return geometry

    # vertex geometry include [unit length normals, vertex area]
    @staticmethod
    def get_vertex_geometry(vertex, face, face_geometry):
        if tf.shape(face_geometry)[-1]==5:
            face_geometry = tf.concat([face_geometry[:,:3], face_geometry[:,4:]], axis=-1)
        geometry = compute_vertex_geometry(vertex[:,:3], face, face_geometry)
        return geometry

    # Count the number of adjacent faces for output vertices, i.e. vertices
    # with vtMap[i]>=0
    @staticmethod
    def get_vertex_adjface(face, vtMap, vertexOut):
        nf_count = count_vertex_adjface(face, vtMap, vertexOut)
        return nf_count

    @staticmethod
    def combine_vertex_clusters(rep_highRes, map_highRes, rep_lowRes, map_lowRes):
        rep_combined, map_combined = combine_clusters(rep_highRes, map_highRes,
                                                      rep_lowRes, map_lowRes)
        return rep_combined, map_combined

    # compute the weights for upsampling/unpooling
    @staticmethod
    def get_upsample_weight(data_highRes, data_lowRes, vt_replace, vt_map, is_normal=False):
        weight = mesh_metric2weight(data_highRes, data_lowRes, vt_replace, vt_map,
                                    is_normal=is_normal)
        return weight

    # compute how many interior points to interpolate in each triangular face
    # based on the face's area
    @staticmethod
    def get_interpolate_num(face_area, max_num=3, min_num=1):
        min_area = tf.reduce_min(face_area)
        max_area = tf.reduce_max(face_area)
        raw_interval = (max_num-min_num)*(face_area-min_area)/(max_area-min_area)
        num_interval = tf.cast(raw_interval, dtype=tf.int32) + \
                       tf.constant(min_num, tf.int32)
        return num_interval

    # build mesh hierarchy for neural network of different mesh resolutions
    def build_mesh_hierarchy(self, vertex_in, face_in, nv_in, mf_in, num_samples):
        mesh_hierarchy = []
        geometry_in = self.get_triangle_geometry(vertex_in, face_in)
        mesh_hierarchy.append((vertex_in, face_in, geometry_in, nv_in, mf_in, None, None))
        for nv_sample in num_samples:
            dec_mesh = self.simplify_mesh(vertex_in, face_in, geometry_in, nv_in, mf_in,
                                          nvSample=nv_sample)
            mesh_hierarchy.append(dec_mesh)

            vertex_in, face_in, geometry_in, nv_in, mf_in = dec_mesh[:5]

        return mesh_hierarchy

    @staticmethod  # reshape data from 2D to 3D for normalization
    def _reshape_to_3D(inputs, nv_in, fix_size):
        in_channels = inputs.shape[-1]
        batch_size = tf.shape(nv_in)[0]
        nv_in = tf.math.cumsum(nv_in)
        ta = tf.TensorArray(tf.float32, size=0, dynamic_size=True)
        for b in tf.range(batch_size):
            if b == 0:
                start = 0
            else:
                start = nv_in[b - 1]
            end = nv_in[b]

            ids = tf.range(start, end, dtype=tf.int32)
            curr_size = end - start
            # padding each sample to fixed size by random selecting among
            # its existing features
            if (fix_size - curr_size)>0:
                add_ids = tf.random.uniform([fix_size - curr_size], minval=start,
                                            maxval=end, dtype=tf.int32)
                ids = tf.concat([ids, add_ids], axis=0)
            per_sample = tf.gather(inputs, ids)
            ta = ta.write(b, per_sample)
        batch_inputs = tf.reshape(ta.stack(),shape=[batch_size,fix_size,in_channels])
        return batch_inputs

    @staticmethod
    def _reshape_from_3D(batch_inputs, nv_in):
        in_channels = batch_inputs.shape[-1]
        batch_size = nv_in.shape[0]
        ta = tf.TensorArray(tf.float32, size=0, dynamic_size=True, infer_shape=False)
        for b in tf.range(batch_size):
            curr_size = nv_in[b]
            per_sample = batch_inputs[b,:curr_size,:]
            ta = ta.write(b, per_sample)
        inputs = tf.reshape(ta.concat(), shape=[tf.reduce_sum(nv_in), in_channels])
        return inputs


