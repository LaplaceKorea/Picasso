import tensorflow as tf
import tensorflow_addons as tfa
import os, sys
import numpy as np
from lib3d.mesh.utils import meshUtil
from tensorflow.python.util.tf_export import keras_export

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(os.path.dirname(BASE_DIR))

#==============================import the mesh convolution modules==============================
sys.path.append(os.path.join(ROOT_DIR, 'tf_ops/mesh/convolution'))
sys.path.append(os.path.join(ROOT_DIR, 'tf_ops/mesh/pooling'))
sys.path.append(os.path.join(ROOT_DIR, 'tf_ops/mesh/unpooling'))
import tf_mesh_conv3d, tf_mesh_pool3d, tf_mesh_unpool3d
#======================================End of importing=========================================


def _filter_variable_(name, shape, stddev, use_xavier=True):
    """Helper to create an initialized Variable with weight decay.

    Note that the Variable is initialized with a truncated normal distribution.
    A weight decay is added only if one is specified.

    Args:
        name: name of the variable
        shape: list of ints
        stddev: standard deviation of a truncated Gaussian
        use_xavier: bool, whether to use the Xavier(Glorot) normal initializer
    Returns:
        Variable Tensor
    """
    if use_xavier:
        initializer = tf.keras.initializers.GlorotNormal()
    else:
        initializer = tf.keras.initializers.TruncatedNormal(stddev=stddev)
    # variable is trainable in default.
    var = tf.Variable(initial_value=initializer(shape=shape), name=name, dtype=tf.float32)
    return var


class texture_conv3d(tf.Module):
    """ 3D separable convolution with non-linear operation.
    Args:
       input: 2-D float32 array, vertex/point features concatenated along axis=0
       num_out_channels: int
       depth_multiplier: int
       intrpl_wgts: 2-D float32 array, face interior interpolation weights
       num_interior: 1-D int32 array, number of interior points in each facet
       face_geometry: 2-D float32 array, geometry of each output face
       use_xavier: bool, use xavier_initializer if true
       stddev: float, stddev for truncated_normal init
       activation_fn: function
    Returns:
       Variable tensor
    """
    def __init__(self, in_channels, out_channels, depth_multiplier=1,
                 scope='', use_xavier=True, stddev=1e-3, activation_fn=tf.nn.elu):
        super(texture_conv3d,self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.multiplier = depth_multiplier
        self.scope = scope
        self.use_xavier = use_xavier
        self.stddev = stddev
        self.activation_fn = activation_fn
        self.filter = {}

    def build_kernel(self):
        # depthwise kernel shape
        f2f_kernel_shape = [3, self.in_channels, self.multiplier]
        self.filter['depthwise'] = _filter_variable_(self.scope+'/F2F_depthwise_weights',
                                       shape=f2f_kernel_shape, use_xavier=self.use_xavier,
                                       stddev=self.stddev)
        # pointwise kernel shape
        kernel_shape = [self.in_channels*self.multiplier+self.add_channels,
                        self.out_channels]
        self.filter['pointwise'] = _filter_variable_(self.scope+'/F2F_pointwise_weights',
                                       shape=kernel_shape, use_xavier=self.use_xavier,
                                       stddev=self.stddev)
        # biases term
        self.filter['biases'] = tf.Variable(tf.zeros(self.out_channels,dtype=tf.float32),
                                            name=self.scope+'/F2F_biases')

    def __call__(self, inputs, intrpl_wgts, num_interior, face_geometry=None):
        if face_geometry is not None:
            self.add_channels = tf.shape(face_geometry)[-1]
        else:
            self.add_channels = 0

        if not self.filter:
            self.build_kernel()

        outputs = tf_mesh_conv3d.facet2facet_conv3d(inputs, self.filter['depthwise'],
                                                    intrpl_wgts, num_interior)
        if face_geometry is not None:
            outputs = tf.concat([outputs, face_geometry], axis=-1)
        outputs = tf.matmul(outputs, self.filter['pointwise'])
        outputs = tf.nn.bias_add(outputs, self.filter['biases'])
        if self.activation_fn is not None:
            outputs = self.activation_fn(outputs)
        return outputs


class vertex2facet_conv3d(tf.Module):
    """ 3D separable convolution with non-linear operation.
    Args:
        input: 2-D float32 array, vertex/point features concatenated along axis=0
        num_out_channels: int scalar
        depth_multiplier: int scalar
        face_list: 2-D int32 array, facet vertex indices
        num_interval: 1-D int32 array, determine the number of interpolated
                      interiors with formula (n+1)(n+2)/2
        face_geometry: 2-D float32 array, geometry of each output face
        use_xavier: bool, use xavier_initializer if true
        stddev: float, stddev for truncated_normal init
        activation_fn: function
        is_training: bool Tensor variable
    Returns:
        Variable tensor
    """
    def __init__(self, in_channels, out_channels, depth_multiplier=1,
                 scope='', use_xavier=True, stddev=1e-3, activation_fn=tf.nn.elu):
        super(vertex2facet_conv3d,self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.multiplier = depth_multiplier
        self.scope = scope
        self.use_xavier = use_xavier
        self.stddev = stddev
        self.activation_fn = activation_fn
        self.filter = {}

    def build_kernel(self):
        # depthwise kernel shape
        v2f_kernel_shape = [3, self.in_channels, self.multiplier]
        self.filter['depthwise'] = _filter_variable_(self.scope+'/V2F_depthwise_weights',
                                      shape=v2f_kernel_shape, use_xavier=self.use_xavier,
                                      stddev=self.stddev)
        # pointwise kernel shape
        kernel_shape = [self.in_channels*self.multiplier+self.add_channels,
                        self.out_channels]
        self.filter['pointwise'] = _filter_variable_(self.scope+'/V2F_pointwise_weights',
                                      shape=kernel_shape, use_xavier=self.use_xavier,
                                      stddev=self.stddev)
        # biases term
        self.filter['biases'] = tf.Variable(tf.zeros(self.out_channels, dtype=tf.float32),
                                            name=self.scope+'/V2F_biases')

    def __call__(self, inputs, face, num_interval, face_geometry=None):
        if face_geometry is not None:
            self.add_channels = face_geometry.get_shape()[-1]
        else:
            self.add_channels = 0

        if not self.filter:
            self.build_kernel()

        outputs = tf_mesh_conv3d.vertex2facet_conv3d(inputs, self.filter['depthwise'],
                                                     face, num_interval)
        if face_geometry is not None:
            outputs = tf.concat([outputs, face_geometry], axis=-1)
        outputs = tf.matmul(outputs, self.filter['pointwise'])
        outputs = tf.nn.bias_add(outputs, self.filter['biases'])
        if self.activation_fn is not None:
            outputs = self.activation_fn(outputs)
        return outputs


class build_gmm_coeff(tf.Module):
    # get gmm components' means and covariances
    # return fuzzy filter coefficients based on
    # the gmm components
    def __init__(self, kernel_size, scope):
        super(build_gmm_coeff, self).__init__()
        self.kernel_size = kernel_size
        self.scope = scope
        self.gmm = {}

    def build_gmm(self, trainable=True, init_means=None, init_covars=None):
        initializer = tf.keras.initializers.RandomNormal()
        shape = [self.kernel_size, 3]
        if init_means is None:
            init_means = initializer(shape=shape)
        if init_covars is None:
            init_covars = initializer(shape=[self.kernel_size])

        # gmm center does not drift too much within the training,
        # switch it to not trainable
        Means = tf.Variable(initial_value=init_means, trainable=False,
                            name=self.scope + '/means', dtype=tf.float32)
        Covars = tf.Variable(initial_value=init_covars, trainable=trainable,
                             name=self.scope + '/covars', dtype=tf.float32)
        self.gmm['means'] = Means
        self.gmm['covars'] = Covars

    def __call__(self, face_normals, trainable=True, init_means=None, init_covars=None):
        if not self.gmm:
            self.build_gmm(trainable, init_means, init_covars)

        # go for the simple solution, we use diagonal covariances
        filt_coeff = tf_mesh_conv3d.compute_gmm_diagonal_coeffs(face_normals,
                                       self.gmm['means'], self.gmm['covars'])
        return filt_coeff


class facet2vertex_conv3d(tf.Module):
    """ 3D separable convolution with non-linear operation.
     Args:
         input: 2-D float32 array, vertex/point features concatenated along axis=0
         num_out_channels: int scalar
         kernel_size: int scalar
         depth_multiplier: int scalar
         face_list: 2-D int32 array, facet vertex indices
         nf_count: 1-D int32 array, number of adjacent faces of each vertex
         vt_map: 1-D int32 array, input to output vertex index mapping
         filt_coeff: 2-D float32 array, GMM component coefficients for each model
         nv_in: int32 vector storing vertex number of each sample
         nv_sample: the used-defined expected vertex size of the decimated mesh
         use_xavier: bool, use xavier_initializer if true
         stddev: float, stddev for truncated_normal init
         activation_fn: function
         with_bn: bool, whether to use batch norm
         with_bias: bool, whether to use bias
         is_training: bool Tensor variable
     Returns:
         Variable tensor
     """
    def __init__(self, in_channels, out_channels, kernel_size, depth_multiplier=1,
                 scope='', use_xavier=True, stddev=1e-3, with_bn=True,
                 with_bias=False, activation_fn=tf.nn.elu):
        super(facet2vertex_conv3d, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.multiplier = depth_multiplier
        self.scope = scope
        self.use_xavier = use_xavier
        self.stddev = stddev
        self.with_bn = with_bn
        self.with_bias = with_bias
        self.activation_fn = activation_fn
        self.filter = {}
        self.BatchNorm = batch_normalization(scope=scope)

    def build_kernel(self):
        # depthwise kernel shape
        f2v_kernel_shape = [self.kernel_size, self.in_channels, self.multiplier]
        self.filter['depthwise'] = _filter_variable_(self.scope+'/F2V_depthwise_weights',
                                      shape=f2v_kernel_shape, use_xavier=self.use_xavier,
                                      stddev=self.stddev)
        # pointwise kernel shape
        kernel_shape = [self.in_channels*self.multiplier, self.out_channels]
        self.filter['pointwise'] = _filter_variable_(self.scope+'/F2V_pointwise_weights',
                                      shape=kernel_shape, use_xavier=self.use_xavier,
                                      stddev=self.stddev)
        # biases term
        if self.with_bias:
            self.filter['biases'] = tf.Variable(tf.zeros(self.out_channels,dtype=tf.float32),
                                                name=self.scope+'/F2V_biases')

    def __call__(self, inputs, face, nf_count, vt_map, filt_coeff,
                 nv_in=None, nv_sample=None, is_training=None):
        if not self.filter:
            self.build_kernel()

        outputs = tf_mesh_conv3d.facet2vertex_conv3d(inputs, self.filter['depthwise'],
                                                     filt_coeff, face, nf_count, vt_map)
        outputs = tf.matmul(outputs, self.filter['pointwise'])
        if self.with_bias:
            outputs = tf.nn.bias_add(outputs, self.filter['biases'])
        if self.activation_fn is not None:
            outputs = self.activation_fn(outputs)
        if self.with_bn and (nv_in is not None) and (nv_sample is not None):
            # outputs = self.BatchNorm(outputs, nv_in, nv_sample, is_training)
            outputs = self.BatchNorm(outputs, is_training)
        return outputs


class vertex2vertex_conv3d(tf.Module):

    # out_channels and depth_multiplier are vectors of 2 values.
    def __init__(self, in_channels, dual_out_channels, kernel_size,
                 dual_depth_multiplier=np.asarray([1,1]),
                 scope='', use_xavier=True, stddev=1e-3,
                 with_bn=True, with_bias=False, activation_fn=tf.nn.elu):
        super(vertex2vertex_conv3d, self).__init__()
        self.V2F_conv3d = vertex2facet_conv3d(in_channels, dual_out_channels[0],
                                              dual_depth_multiplier[0], scope, use_xavier,
                                              stddev, activation_fn)
        self.F2V_conv3d = facet2vertex_conv3d(dual_out_channels[0], dual_out_channels[1],
                                              kernel_size, dual_depth_multiplier[1], scope,
                                              use_xavier, stddev, with_bn,
                                              with_bias, activation_fn)

    def __call__(self, inputs, face, nf_count, vt_map, filt_coeff, num_interval,
                 nv_in=None, nv_sample=None, is_training=None, face_geometry=None):
        outputs = self.V2F_conv3d(inputs, face, num_interval, face_geometry)
        outputs = self.F2V_conv3d(outputs, face, nf_count, vt_map, filt_coeff,
                                  nv_in, nv_sample, is_training)
        return outputs


class pointwise_conv3d(tf.Module):
    """ pointwise convolution with non-linear operation.
    Args:
        input: 2-D float32 array, point features concatenated along axis=0
        num_out_channels: int
        nv_in: int32 vector storing vertex number of each sample
        nv_sample: the used-defined expected vertex size of the decimated mesh
        use_xavier: bool, use xavier_initializer if true
        stddev: float, stddev for truncated_normal init
        activation_fn: function
        with_bn: bool, whether to use batch norm
        is_training: bool Tensor variable
    Returns:
      Variable tensor
    """
    def __init__(self, in_channels, out_channels, scope='', use_xavier=True, stddev=1e-3,
                 with_bn=True, with_bias=False, activation_fn=tf.nn.elu):
        super(pointwise_conv3d, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.scope = scope
        self.use_xavier = use_xavier
        self.stddev = stddev
        self.with_bn = with_bn
        self.with_bias = with_bias
        self.activation_fn = activation_fn
        self.filter = {}
        self.BatchNorm = batch_normalization(scope=scope)

    def build_kernel(self):
        # pointwise kernel shape
        kernel_shape = [self.in_channels, self.out_channels]
        self.filter['pointwise'] = _filter_variable_(self.scope+'/pointwise_weights',
                                       shape=kernel_shape, use_xavier=self.use_xavier,
                                       stddev=self.stddev)
        # biases term
        if self.with_bias:
            self.filter['biases'] = tf.Variable(tf.zeros(self.out_channels, dtype=tf.float32),
                                                name=self.scope+'/biases')

    def __call__(self, inputs, nv_in=None, nv_sample=None, is_training=None):
        if not self.filter:
            self.build_kernel()

        outputs = tf.matmul(inputs, self.filter['pointwise'])
        if self.with_bias:
            outputs = tf.nn.bias_add(outputs, self.filter['biases'])
        if self.activation_fn is not None:
            outputs = self.activation_fn(outputs)
        if self.with_bn and (nv_in is not None) and (nv_sample is not None):
            # outputs = self.BatchNorm(outputs, nv_in, nv_sample, is_training)
            outputs = self.BatchNorm(outputs, is_training)
        return outputs


class pool3d(tf.Module):
    """ 3D Mesh pooling.
    Args:
        inputs: 2-D float32 array, point features concatenated along axis=0
        vt_replace: int32 vector, vertex clustering information in mesh decimation
        vt_map: int32 vector, input to output vertex index mapping
        vt_out: 2-D float array, vertices in the decimated mesh,
                help to get shape of output features
        method: string, the pooling method
        weight: float32 array, weights for weighted pooling,
                similar to the weighted unpooling
    Returns:
        Variable tensor
    """
    def __init__(self, method='max'):
        super(pool3d, self).__init__()
        self.method = method

    def __call__(self, inputs, vt_replace, vt_map, vt_out, weight=None):
        if self.method == 'max':
            outputs, max_index = tf_mesh_pool3d.max_pool3d(inputs, vt_replace,
                                                           vt_map, vt_out)
        elif self.method == 'avg':
            outputs = tf_mesh_pool3d.avg_pool3d(inputs, vt_replace,
                                                vt_map, vt_out)
        elif self.method == 'weighted':
            outputs = tf_mesh_pool3d.weighted_pool3d(inputs, weight,
                                                     vt_replace, vt_map, vt_out)
        else:
            raise ValueError("Unknow pooling method %s."%self.method)

        return outputs


class unpool3d(tf.Module):
    """ 3D Mesh unpooling
    Args:
        inputs: 2-D float32 array, point features concatenated along axis=0
        vt_replace: int32 vector, vertex clustering information in mesh decimation
        vt_map: int32 vector, input to output vertex index mapping
        method: string, the unpooling method
        weight: float32 array, weights for weighted pooling,
                similar to the weighted unpooling
    Returns:
        Variable tensor
    """
    def __init__(self):
        super(unpool3d, self).__init__()

    def __call__(self, inputs, vt_replace, vt_map):
        outputs = tf_mesh_unpool3d.mesh_interpolate(inputs, vt_replace, vt_map)

        return outputs


class batch_normalization(tf.Module, meshUtil):
    def __init__(self, scope=''):
        super(batch_normalization,self).__init__()
        self.norm_fn = tf.keras.layers.BatchNormalization(axis=-1, momentum=0.99,
                                    beta_regularizer=tf.keras.regularizers.l2(1.0),
                                    gamma_regularizer=tf.keras.regularizers.l2(1.0),
                                    name=scope+'/BN')

    def __call__(self, data, is_training):
        return self.norm_fn(data, training=is_training)

    # def __call__(self, inputs, nv_in, nv_sample, is_training):
    #     batch_inputs = self._reshape_to_3D(inputs, nv_in, nv_sample)  # reshape to get batch dimension
    #     batch_outputs = self.norm_fn(batch_inputs, training=is_training)
    #     outputs = self._reshape_from_3D(batch_outputs, nv_in)
    #     return outputs


class dropout(tf.Module):

    def __init__(self, drop_rate=0.6):
        super(dropout,self).__init__()
        self.DP = tf.keras.layers.Dropout(rate=drop_rate)

    def __call__(self, inputs, is_training):
        return self.DP(inputs, training=is_training)
