import tensorflow as tf
from termcolor import colored

class Dataset:

    def __init__(self, fileList):
        self.dataset = tf.data.Dataset.from_tensor_slices(fileList)

    def shuffle(self, buffer_size=10000):
        self.dataset = self.dataset.shuffle(buffer_size)
        return self

    def map(self, parse_fn, is_training=True):
        self.parse_fn = parse_fn
        self.is_training = is_training
        self.dataset = tf.data.TFRecordDataset(self.dataset)
        return self

    def batch(self, batch_size, drop_remainder=False):
        # c2f_map: crop to full mesh index mapping
        face_offset_idx = 0
        vertex, face, nv, mf, label, c2f_map = [], [], [], [], [], []
        for raw_record in self.dataset.take(-1):
            data = self.parse_fn(raw_record.numpy(), is_training=self.is_training)

            if data is not None:
                vertex.append(data[0])
                face.append(data[1] + face_offset_idx)
                nv.append(data[2])
                mf.append(data[3])
                label.append(data[4])
                c2f_map.append(data[5])
                face_offset_idx += data[2][0]
            if len(nv) == batch_size:
                vertex = tf.concat(vertex, axis=0)
                face = tf.concat(face, axis=0)
                nv = tf.concat(nv, axis=0)
                mf = tf.concat(mf, axis=0)
                label = tf.concat(label, axis=0)
                c2f_map = tf.concat(c2f_map, axis=0)

                nv = tf.reshape(nv,shape=[batch_size])
                mf = tf.reshape(mf,shape=[batch_size])
                mesh = (vertex, face, nv, mf)
                yield mesh, label, c2f_map

                face_offset_idx = 0
                vertex, face, nv, mf, label, c2f_map = [], [], [], [], [], []


        if not drop_remainder and len(nv)>0:
            vertex = tf.concat(vertex, axis=0)
            face = tf.concat(face, axis=0)
            nv = tf.concat(nv, axis=0)
            mf = tf.concat(mf, axis=0)
            label = tf.concat(label, axis=0)
            c2f_map = tf.concat(c2f_map, axis=0)
            mesh = (vertex, face, nv, mf)
            yield mesh, label, c2f_map